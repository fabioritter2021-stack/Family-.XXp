const KEY="familyxp-data";
const defaultData={parents:[],children:[],tasks:[],rewards:[],session:null};
let db=JSON.parse(localStorage.getItem(KEY)||"null")||defaultData;
const save=()=>localStorage.setItem(KEY,JSON.stringify(db));
const id=()=>Date.now().toString(36)+Math.random().toString(36).slice(2);
const app=document.getElementById("app");
let page="home";

if(!db.parents.length){
  db.parents.push({id:id(),name:"Demo Eltern",email:"parent@example.com",password:"1234",goal:10000});
  db.children.push({id:id(),parentId:db.parents[0].id,name:"Max",username:"max123",password:"1234",xp:1250});
  db.children.push({id:id(),parentId:db.parents[0].id,name:"Lena",username:"lena123",password:"1234",xp:800});
  db.tasks.push({id:id(),childId:db.children[0].id,title:"Zimmer aufräumen",xp:100,status:"open",photo:null});
  db.rewards.push({id:id(),parentId:db.parents[0].id,childId:db.children[0].id,title:"Spielecenter",xp:10000,description:"Ein Besuch im Spielecenter"});
  save();
}

function login(){
 app.innerHTML=`<main class="wrap">
 <div class="logo">⭐ FamilyXP</div><div class="sub">Aufgaben → XP → Belohnungen</div>
 <div class="card"><div class="tabs"><button id="p" class="active" onclick="mode('parent')">👨 Eltern</button><button id="c" onclick="mode('child')">👦 Kind</button></div>
 <div id="form"></div></div>
 <p class="muted small" style="text-align:center">Demo: Eltern <b>parent@example.com / 1234</b><br>Kind <b>max123 / 1234</b></p></main>`;
 mode("parent");
}
let loginMode="parent";
function mode(m){loginMode=m;document.getElementById("p").className=m==="parent"?"active":"";document.getElementById("c").className=m==="child"?"active":"";document.getElementById("form").innerHTML=`
 <input id="u" placeholder="${m==="parent"?"E-Mail":"Benutzername"}">
 <input id="pw" type="password" placeholder="Passwort">
 <button style="width:100%" onclick="doLogin()">Anmelden</button>`}
function doLogin(){
 const u=document.getElementById("u").value.trim(),p=document.getElementById("pw").value;
 let acc=loginMode==="parent"?db.parents.find(x=>x.email===u&&x.password===p):db.children.find(x=>x.username===u&&x.password===p);
 if(!acc){alert("Anmeldung nicht korrekt.");return}
 db.session={role:loginMode,id:acc.id};save();page="home";render();
}
function current(){return db.session?.role==="parent"?db.parents.find(x=>x.id===db.session.id):db.children.find(x=>x.id===db.session.id)}
function render(){
 if(!db.session){login();return}
 const a=current();
 if(db.session.role==="parent") parent();
 else child();
}
function header(title){return `<div class="row"><h2>${title}</h2><button class="secondary small" onclick="logout()">Abmelden</button></div>`}
function nav(){return `<div class="nav"><button class="${page==='home'?'active':''}" onclick="page='home';render()">🏠 Start</button><button class="${page==='tasks'?'active':''}" onclick="page='tasks';render()">✅ Aufgaben</button><button class="${page==='rewards'?'active':''}" onclick="page='rewards';render()">🎁 Belohnungen</button></div>`}
function parent(){
 const p=current(), kids=db.children.filter(c=>c.parentId===p.id);
 let body=page==="home"?parentHome(p,kids):page==="tasks"?parentTasks(p,kids):parentRewards(p,kids);
 app.innerHTML=`<main class="wrap">${body}</main>${nav()}`;
}
function parentHome(p,kids){return `${header("FamilyXP")}
<div class="card"><h3>Familienziel</h3><div class="xp">${p.goal.toLocaleString()} XP</div><div class="muted">Ziel für Belohnungen</div><button class="secondary" onclick="setGoal()">XP-Ziel ändern</button></div>
<h3>Kinder</h3>${kids.map(k=>`<div class="card"><div class="row"><div><b>${k.name}</b><div class="muted">@${k.username}</div></div><span class="xp">${k.xp} XP</span></div><div class="bar"><div style="width:${Math.min(100,k.xp/p.goal*100)}%"></div></div></div>`).join("")}
<div class="card"><h3>Kind hinzufügen</h3><input id="cn" placeholder="Name"><input id="cu" placeholder="Benutzername"><input id="cp" placeholder="Passwort"><button onclick="addChild()">Kind erstellen</button></div>`}
function parentTasks(p,kids){return `${header("Aufgaben")}<div class="card"><h3>Neue Aufgabe</h3><select id="tc">${kids.map(k=>`<option value="${k.id}">${k.name}</option>`).join("")}</select><input id="tt" placeholder="Aufgabe"><input id="tx" type="number" placeholder="XP"><button onclick="addTask()">Aufgabe erstellen</button></div>
${db.tasks.filter(t=>kids.some(k=>k.id===t.childId)).map(t=>{let k=kids.find(x=>x.id===t.childId);return `<div class="card"><div class="row"><div><b>${t.title}</b><div class="muted">${k.name} · ${t.xp} XP</div></div><span class="tag">${t.status}</span></div>${t.photo?`<img class="photo" src="${t.photo}" style="max-width:100%;border-radius:12px">`:""}${t.status==="submitted"?`<button onclick="approve('${t.id}')">✓ Bestätigen</button>`:""}</div>`}).join("")}`}
function parentRewards(p,kids){return `${header("Belohnungen")}<div class="card"><h3>Belohnung erstellen</h3><select id="rc">${kids.map(k=>`<option value="${k.id}">${k.name}</option>`).join("")}</select><input id="rt" placeholder="z. B. Spielecenter"><input id="rx" type="number" placeholder="Benötigte XP"><input id="rd" placeholder="Beschreibung"><button onclick="addReward()">Belohnung speichern</button></div>
${db.rewards.filter(r=>r.parentId===p.id).map(r=>`<div class="card"><b>🎁 ${r.title}</b><div>${r.xp.toLocaleString()} XP</div><div class="muted">${r.description||""}</div></div>`).join("")}`}
function child(){
 const c=current(), p=db.parents.find(x=>x.id===c.parentId);
 let body=page==="home"?childHome(c,p):page==="tasks"?childTasks(c):childRewards(c);
 app.innerHTML=`<main class="wrap">${body}</main>${nav()}`;
}
function childHome(c,p){return `${header("Hallo "+c.name+" 👋")}<div class="card"><div class="muted">Deine XP</div><div class="xp">${c.xp.toLocaleString()}</div><div class="muted">Ziel: ${p?.goal.toLocaleString()||"—"} XP</div><div class="bar"><div style="width:${Math.min(100,c.xp/(p?.goal||1)*100)}%"></div></div></div><div class="card"><h3>Deine nächste Belohnungen</h3>${db.rewards.filter(r=>r.childId===c.id).map(r=>`<p>🎁 <b>${r.title}</b> – ${r.xp.toLocaleString()} XP</p>`).join("")||"<p class='muted'>Noch keine Belohnungen.</p>"}</div>`}
function childTasks(c){return `${header("Meine Aufgaben")}${db.tasks.filter(t=>t.childId===c.id).map(t=>`<div class="card"><div class="row"><div><b>${t.title}</b><div>${t.xp} XP</div></div><span class="tag">${t.status}</span></div>${t.status==="open"?`<input type="file" accept="image/*" capture="environment" onchange="submitPhoto('${t.id}',this)">`:""}${t.status==="approved"?`<div>🎉 XP gutgeschrieben!</div>`:""}</div>`).join("")||"<p class='muted'>Keine Aufgaben.</p>"}`}
function childRewards(c){return `${header("Belohnungen")}${db.rewards.filter(r=>r.childId===c.id).map(r=>`<div class="card"><h3>🎁 ${r.title}</h3><div class="xp">${r.xp.toLocaleString()} XP</div><p>${r.description||""}</p><div class="muted">${c.xp>=r.xp?"Du hast genug XP!":"Noch "+(r.xp-c.xp).toLocaleString()+" XP"}</div></div>`).join("")}`}
function addChild(){let p=current(),n=cn.value.trim(),u=cu.value.trim(),pw=cp.value;if(!n||!u||!pw)return alert("Bitte alles ausfüllen.");if(db.children.some(c=>c.username===u)||db.parents.some(x=>x.email===u))return alert("Benutzername bereits vergeben.");db.children.push({id:id(),parentId:p.id,name:n,username:u,password:pw,xp:0});save();render()}
function addTask(){let p=current(),c=tc.value,t=tt.value.trim(),x=Number(tx.value);if(!t||!x)return alert("Bitte Aufgabe und XP eingeben.");db.tasks.push({id:id(),childId:c,title:t,xp:x,status:"open",photo:null});save();render()}
function addReward(){let p=current(),c=rc.value,t=rt.value.trim(),x=Number(rx.value),d=rd.value.trim();if(!t||!x)return alert("Bitte Belohnung und XP eingeben.");db.rewards.push({id:id(),parentId:p.id,childId:c,title:t,xp:x,description:d});save();render()}
function setGoal(){let p=current(),g=prompt("Neues XP-Ziel:",p.goal);if(g&&Number(g)>0){p.goal=Number(g);save();render()}}
function approve(tid){let t=db.tasks.find(x=>x.id===tid);if(!t||t.status==="approved")return;t.status="approved";let c=db.children.find(x=>x.id===t.childId);if(c)c.xp+=t.xp;save();render()}
function submitPhoto(tid,input){let f=input.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{let t=db.tasks.find(x=>x.id===tid);t.status="submitted";t.photo=r.result;save();render()};r.readAsDataURL(f)}
function logout(){db.session=null;save();render()}
if("serviceWorker"in navigator)navigator.serviceWorker.register("./sw.js").catch(()=>{});
render();
